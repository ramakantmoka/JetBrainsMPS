#ifndef HELLO_H
#define HELLO_H


#include <stdint.h>

#include <stddef.h>

#include <stdbool.h>

#include "UnitTestMessages_copied.h"



#ifdef __cplusplus
extern "C" {
#endif

int32_t  hello_add(void);

int32_t  hello_main(int32_t argc, char *(argv[]));


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
